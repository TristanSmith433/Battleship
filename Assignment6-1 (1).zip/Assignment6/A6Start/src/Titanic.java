
import battleship.*;

import java.awt.Point;
import java.util.*;
/*
 "StAuth10244: I Tristan smith,
        * 000825589 certify that this material is my original work.
        * No other person's work has been used without due acknowledgement.
        *  I have not made my work available to anyone else."
 */

/**
 * Battleship shooter - Takes precaution on double shooting and has a shoot
 * every other space strategy
 * <p>
 * a ship is hit - This is not a good solution to the problem!
 *
 * @author Tristan Smith ()
 */

public class Titanic implements BattleShipBot {
    private BattleShip2 battleShip;
    private int currentCellX;// current cell we are on
    private int currentCellY;
    private ArrayList<ArrayList<Integer>> board = new ArrayList<>();
    private boolean isSinkMode;
    private int numHits;
    private final String[] direction = {"top", "right", "bottom", "left"};
    private int directionIndex = 0;
    private boolean isHorizontal;
    private int lastHitX;
    private int lastHitY;

    /**
     * Constructor keeps a copy of the BattleShip instance
     * Created instances of any Data Structures and initialize any variables here
     *
     * @param b created battleship instance - should be a new game
     * @author Tristan Smith
     */

    @Override
    public void initialize(BattleShip2 b) {
        // initialize all the variables when new game starts
        battleShip = b;
        int gameSize = BattleShip2.BOARD_SIZE;
        // setting our cells to 0 we want to increase the spots by 2
        currentCellX = -1;
        currentCellY = 0;
        isSinkMode = false;
        numHits = 0;
        isHorizontal = false;
        lastHitX = 0;
        lastHitY = 0;
        directionIndex = 0;
        // Need to use a Seed if you want the same results to occur from run to run
        // This is needed if you are trying to improve the performance of your code
        board = new ArrayList<>();
        for (int i = 0; i < gameSize; i++) {
            ArrayList<Integer> row = new ArrayList<>();
            for (int j = 0; j < gameSize; j++) {
                row.add(0);
            }
            board.add(row);
        }

    }


    /**
     * we want to open up area if we hit ship
     * once you hit a ship next shot hits neighbor
     * doesn't hit area again
     * shoots every second space
     * goes top left bottom right once we have shot ship twice it either shoots the bottom and top if its vertical if its horizontal we shoot left and right
     * once we have got 2 shots completed
     * once its sunk we go back to hunting
     * The BattleShip API will call until all ships are sunk
     */
    @Override
    public void fireShot() {
        // hunt till we hit once we hit we go to sink mode

        // hunt mode
        // think of mod by 4

        int xToShoot = 0;
        int yToShoot = 0;
        int orientation = -1;
        boolean foundValue = false;

        // check if sink mode is enabled or not
        if (isSinkMode) {
            // check the number of hits so far
            if (numHits == 1) {
                // check what direction we currently have to check and if direction is invalid then move to the next direction
                // set yToShoot and xToShoot for the current direction
                //moves to the right next ot hit area
                //moves to under the hit area
                //moves to the left of the hit area
                switch (direction[directionIndex]) {
                    case "top" -> {
                        if (!isValidPosition(lastHitX, lastHitY - 1)) {
                            directionIndex++;
                            return;
                        }
                        yToShoot = lastHitY - 1;
                        xToShoot = lastHitX;
                        orientation = 0;
                    }
                    case "right" -> {
                        if (!isValidPosition(lastHitX + 1, lastHitY)) {
                            directionIndex++;
                            return;
                        }
                        xToShoot = lastHitX + 1;
                        yToShoot = lastHitY;
                        orientation = 1;
                    }
                    case "bottom" -> {
                        if (!isValidPosition(lastHitX, lastHitY + 1)) {
                            directionIndex++;
                            return;
                        }
                        yToShoot = lastHitY + 1;
                        xToShoot = lastHitX;
                        orientation = 0;
                    }
                    case "left" -> {
                        xToShoot = lastHitX - 1;
                        yToShoot = lastHitY;
                        orientation = 1;
                    }
                }
            } else if (numHits >= 2) {
                // if numHits is greater than 2 then direction is already determined
                // if horizontal then move to the next unchecked space horizontally
                // if vertical then move to the next unchecked space vertically
                int index = 0;
                if (isHorizontal) {
                    // keep moving right until either an unknown or empty cell exists
                    while (isValidPosition(lastHitX + index, lastHitY)) {
                        if (board.get(lastHitY).get(lastHitX + index) == -1) {
                            break;
                        }

                        if (board.get(lastHitY).get(lastHitX + index) == 0) {
                            foundValue = true;
                            break;
                        }
                        index++;
                    }

                    // if hidden cell is found then set xToShoot and yToShoot and perform shot
                    if (foundValue) {
                        xToShoot = lastHitX + index;
                        yToShoot = lastHitY;
                    } else {
                        index = 0;
                        // keep moving left until either an unknown or empty cell is found
                        while (isValidPosition(lastHitX - index, lastHitY)) {
                            if (board.get(lastHitY).get(lastHitX - index) == -1) {
                                break;
                            }

                            if (board.get(lastHitY).get(lastHitX - index) == 0) {
                                foundValue = true;
                                break;
                            }
                            index++;
                        }

                        if (foundValue) {
                            xToShoot = lastHitX - index;
                            yToShoot = lastHitY;
                        }
                    }
                    // If an hidden cell is not found then ship has already been discovered so reset
                    if (!foundValue) {
                        setSurroundings(lastHitX, lastHitY, true);
                        isSinkMode = false;
                        numHits = 0;
                        directionIndex = 0;
                        isHorizontal = false;
                        lastHitX = 0;
                        lastHitY = 0;
                        fireShot();
                        return;
                    }
                } else {
                    // Do the same as we did above for horizontal but this time vertically
                    while (isValidPosition(lastHitX, lastHitY + index)) {
                        if (board.get(lastHitY + index).get(lastHitX) == -1) {
                            break;
                        }

                        if (board.get(lastHitY + index).get(lastHitX) == 0) {
                            foundValue = true;
                            break;
                        }
                        index++;
                    }

                    if (foundValue) {
                        xToShoot = lastHitX;
                        yToShoot = lastHitY + index;
                    } else {
                        index = 0;
                        while (isValidPosition(lastHitX, lastHitY - index)) {
                            if (board.get(lastHitY - index).get(lastHitX) == -1) {
                                break;
                            }

                            if (board.get(lastHitY - index).get(lastHitX) == 0) {
                                foundValue = true;
                                break;
                            }
                            index++;
                        }
                        if (foundValue) {
                            xToShoot = lastHitX;
                            yToShoot = lastHitY - index;
                        }
                    }

                    if (!foundValue) {
                        setSurroundings(lastHitX, lastHitY, false);
                        isSinkMode = false;
                        numHits = 0;
                        directionIndex = 0;
                        isHorizontal = false;
                        lastHitX = 0;
                        lastHitY = 0;
                        fireShot();
                        return;
                    }
                }
            }
        } else {
            // if not in sink mode then move two squares forward
            if (currentCellX >= 13) {
                // alternate the starting cell of each row
                currentCellX = currentCellY % 2;
                currentCellY++;
            } else {
                currentCellX += 2;
            }
            if (currentCellX != -2 && board.get(currentCellY).get(currentCellX) != 0) {
                fireShot();
                return;
            }
            xToShoot = currentCellX;
            yToShoot = currentCellY;
        }

        // then actually shoot
        boolean hit = battleShip.shoot(new Point(xToShoot, yToShoot));

        // if we make the hit then mark square on board as hit
        if (hit) {
            board.get(yToShoot).set(xToShoot, 1);
            if (!isSinkMode) {
                numHits = 1;
            } else {
                numHits++;
                if (numHits == 2) {
                    // set direction after two hits are placed on ship
                    isHorizontal = orientation != 0;
                }

            }
            isSinkMode = true;
            lastHitX = xToShoot;
            lastHitY = yToShoot;
        } else {
            // if hit is missed then mark as missed and increase direction index if sink mode is enabled
            board.get(yToShoot).set(xToShoot, -1);
            if (isSinkMode && numHits == 1) {
                directionIndex++;
            }
        }

    }


    // check if it is valid position
    public boolean isValidPosition(int x, int y) {
        return x >= 0 && y >= 0 && x < 15 && y < 15;
    }


    public void setSurroundings(int x, int y, boolean isHorizontal) {
        // set surrounding squares to missed cells once we find a ship
        if (isHorizontal) {
            int index = 0;
            int start = x;
            // keep moving left until the start of the ship
            while (isValidPosition(x - index, y)) {
                if (board.get(y).get(x - index) != 1) {
                    board.get(y).set(x - index, -1);

                    start = x - index + 1;
                    break;
                }
                index++;
            }
            index = 0;
            // keep marking the top and bottom cells until we reach the end of the ship
            while (isValidPosition(start + index, y)) {
                if (board.get(y).get(start + index) != 1) {
                    break;
                }
                if (isValidPosition(start + index, y + 1)) {
                    board.get(y + 1).set(start + index, -1);
                }
                if (isValidPosition(start + index, y - 1)) {
                    board.get(y - 1).set(start + index, -1);
                }
                index++;
            }

        } else {
            int index = 0;
            int start = y;
            while (isValidPosition(x, y - index)) {
                if (board.get(y - index).get(x) != 1) {
                    board.get(y - index).set(x, -1);
                    start = y - index + 1;
                    break;
                }
                index++;
            }
            index = 0;
            while (isValidPosition(x, start + index)) {
                if (board.get(start + index).get(x) != 1) {
                    break;
                }
                if (isValidPosition(x + 1, start + index)) {
                    board.get(start + index).set(x + 1, -1);
                }
                if (isValidPosition(x - 1, start + index)) {
                    board.get(start + index).set(x - 1, -1);
                }
                index++;
            }
        }
    }

    /**
     * Authorship of the solution - must return names of all students that
     * contributed to
     * the solution
     * <p>
     * returns the  names of the authors of the solution
     */

    @Override
    public String getAuthors() {
        return "Tristan Smith 000825589)";
    }
}